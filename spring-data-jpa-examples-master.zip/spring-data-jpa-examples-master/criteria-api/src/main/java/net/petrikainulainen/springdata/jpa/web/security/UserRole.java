package net.petrikainulainen.springdata.jpa.web.security;

/**
 * @author Petri Kainulainen
 */
enum UserRole {
    ROLE_USER
}
