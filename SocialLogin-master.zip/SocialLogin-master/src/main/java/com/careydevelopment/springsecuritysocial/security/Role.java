package com.careydevelopment.springsecuritysocial.security;

public enum Role {
    FACEBOOK_USER, TWITTER_USER;
}
