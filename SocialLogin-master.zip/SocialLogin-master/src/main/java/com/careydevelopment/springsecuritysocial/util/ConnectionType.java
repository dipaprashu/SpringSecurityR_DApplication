package com.careydevelopment.springsecuritysocial.util;

public enum ConnectionType {
    TWITTER, FACEBOOK;
}
