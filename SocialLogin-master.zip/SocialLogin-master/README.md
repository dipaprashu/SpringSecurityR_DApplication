# SocialLogin
This project demonstrates how to integrate Facebook and Twitter login with Spring security.

WARNING! You must update the application.properties files with your own IDs and secrets. Otherwise, this code won't work!

Just pull this project down in Eclipse, then build it. Once it's built, you can run it from the command line with:
java -jar SocialLogin-1.0.jar

Alternatively, you can run it within Eclipse by right-clicking on Application and selecting Run As... Java Application.

Once the application is launched, you can access it at http://localhost:8090/
