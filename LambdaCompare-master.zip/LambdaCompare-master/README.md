# LambdaCompare
This code shows you how to sort objects using both the "classic" method and with lambda expressions.

To see the code in action, just run the SortCustomers class. If you're in Eclipse, just right-click on that class,
select "Run As..." and select "Java Application."
