# TwitterLogin
This project contains a Spring Boot demo that enables a user to login with Twitter

Be sure to add your own consumer key and secret to the GetTokenController class!

Just pull this project down in Eclipse, then build it. Once it's built, you can run it from the command line with:
java -jar twitterlogin-1.0..jar

Alternatively, you can run it within Eclipse by right-clicking on Application and selecting Run As... Java Application.

Once the application is launched, you can access it at http://localhost:8090/twitterLogin
