# springsociallogin-part1

The main aim of this tutorial will be to integrate spring-security and spring-social together and create a web application where users can be registered either by

Registering their details
Google
Facebook
LinkedIn
In this first part of the tutorial, our aim will be to get data from spring-social and then display the details on the page, in the second part we will integrate the spring-security where we will ask the user to enter his details and then store on  DB.
