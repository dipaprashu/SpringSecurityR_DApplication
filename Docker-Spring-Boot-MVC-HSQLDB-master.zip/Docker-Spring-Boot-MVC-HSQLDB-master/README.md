# Docker-Spring-Boot-MVC-HSQLDB
Docker-Spring-Boot-MVC-HSQLDB( In memory DB)

This project is sample project to create a spring boot microservice which uses In memeory HSQL DB
