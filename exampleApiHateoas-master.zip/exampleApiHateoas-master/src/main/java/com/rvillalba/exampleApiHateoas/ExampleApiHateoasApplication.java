package com.rvillalba.exampleApiHateoas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExampleApiHateoasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleApiHateoasApplication.class, args);
	}
}
