package com.rvillalba.exampleApiHateoas.jwt.model;

public interface JwtToken {
    String getToken();
}
