package com.rvillalba.exampleApiHateoas.jwt.exception;

public class InvalidJwtToken extends RuntimeException {
    private static final long serialVersionUID = -294671188037098603L;
}
