# Chart.js and Spring Demo

This is a sample project to demonstrate features of Chart.js and Spring Boot
