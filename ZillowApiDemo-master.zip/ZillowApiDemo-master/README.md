# zillowdemo
A demo showing integration with the Zillow API

Be sure to add your own ZWS ID in the ZillowApiHelper class!

Just pull this project down in Eclipse, then build it. Once it's built, you can run it from the command line with:
java -jar zillowdemo-1.0.jar

Alternatively, you can run it within Eclipse by right-clicking on Application and selecting Run As... Java Application.

Once the application is launched, you can access it at http://localhost:8090/
