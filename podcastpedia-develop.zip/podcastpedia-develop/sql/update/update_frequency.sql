-- TERMINATED
update podcasts
set update_frequency=5
where podcast_id=908; 