insert into special_tables_update 
set podcast_id=1145,
problem_description="PodId[1145] - connect timeout exception";