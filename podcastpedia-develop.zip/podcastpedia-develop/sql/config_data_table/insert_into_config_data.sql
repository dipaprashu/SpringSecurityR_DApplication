insert into config_data 
set property= 'LOCAL_PATH_FOR_FEED',
value = 'C://Podcastpedia//files//feed.xml',
description='file path on local machine to store the feed to be updated';