truncate table conf_recommended_podcasts;
select * from conf_recommended_podcasts;

-- modify recommended podcasts here 
insert into conf_recommended_podcasts set podcast_id = 1;
insert into conf_recommended_podcasts set podcast_id = 1260;
insert into conf_recommended_podcasts set podcast_id = 792;
insert into conf_recommended_podcasts set podcast_id = 4;
insert into conf_recommended_podcasts set podcast_id = 1183;