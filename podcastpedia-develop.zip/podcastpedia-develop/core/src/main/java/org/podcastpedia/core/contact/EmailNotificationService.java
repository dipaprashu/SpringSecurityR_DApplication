package org.podcastpedia.core.contact;

public interface EmailNotificationService {

	public void sendContactNotification(ContactForm contactForm);

}
