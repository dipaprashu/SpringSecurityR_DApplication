package org.podcastpedia.test;

public class AspectJAnnotationTest {

}
