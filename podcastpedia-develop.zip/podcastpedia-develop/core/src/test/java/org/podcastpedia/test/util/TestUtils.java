package org.podcastpedia.test.util;


public interface TestUtils {
	/**
	 * Returns the number of available categories from the database 
	 * @return
	 */
	public Integer getNumberOfCategories();
}
